﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Librapp
{
    public class Reservation
    {
        public int ReservationID { get; set; }
        public int UserID { get; set; }
        public int BookID { get; set; }
        public DateTime ReservationDate { get; set; }
        public DateTime ExpirationDate { get; set; }

        public Reservation(int reservationID, int userID, int bookID, DateTime reservationDate, DateTime expirationDate) // konstruktor
        {
            ReservationID = reservationID;
            UserID = userID;
            BookID = bookID;
            ReservationDate = reservationDate;
            ExpirationDate = expirationDate;
        }
        public Reservation() { } // konstruktor domyślny

        public Reservation(Reservation reservationToCopy) // konstruktor kopiujący
        {
            this.ReservationID = reservationToCopy.ReservationID;
            this.UserID = reservationToCopy.UserID;
            this.BookID = reservationToCopy.BookID;
            this.ReservationDate = reservationToCopy.ReservationDate;
            this.ExpirationDate = reservationToCopy.ExpirationDate;
        }

        public Reservation(int reservationID, User user, Book book, DateTime reservationDate, DateTime expirationDate) // konstruktor z obiektów
        {
            ReservationID = reservationID;
            UserID = user.UserID;
            BookID = book.BookID;
            ReservationDate = reservationDate;
            ExpirationDate = expirationDate;
        }
    }
}
