﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Librapp
{
    public class Borrowing
    {
        public int BorrowingID { get; set; }
        public int UserID { get; set; }
        public int BookID { get; set; }
        public DateTime BorrowingDate { get; set; }
        public DateTime DueDate { get; set; }

        public Borrowing(int borrowingID, int userID, int bookID, DateTime borrowingDate, DateTime dueDate) // konstruktor
        {
            BorrowingID = borrowingID;
            UserID = userID;
            BookID = bookID;
            BorrowingDate = borrowingDate;
            DueDate = dueDate;
        }
        public Borrowing() { } // konstruktor domyślny

        public Borrowing(Borrowing borrowingToCopy) // konstruktor kopiujący
        {
            this.BorrowingID = borrowingToCopy.BorrowingID;
            this.UserID = borrowingToCopy.UserID;
            this.BookID = borrowingToCopy.BookID;
            this.BorrowingDate = borrowingToCopy.BorrowingDate;
            this.DueDate = borrowingToCopy.DueDate;
        }

        public Borrowing(int borrowingID, User user, Book book, DateTime borrowingDate, DateTime dueDate) // konstruktor z obiektów
        {
            BorrowingID = borrowingID;
            UserID = user.UserID;
            BookID = book.BookID;
            BorrowingDate = borrowingDate;
            DueDate = dueDate;
        }
    }
}
