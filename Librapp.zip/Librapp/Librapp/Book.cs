﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Librapp
{
    public class Book
    {
        public int BookID { get; set; }
        public string BookTitle { get; set; }
        public string BookAuthor { get; set; }
        public string Genre { get; set; }
        public string ISBN { get; set; }
        public string Status { get; set; } 

        public Book(int bookID, string bookTitle, string bookAuthor, string genre, string ISBN, string status) // konstruktor
        {
            BookID = bookID;
            BookTitle = bookTitle;
            BookAuthor = bookAuthor;
            Genre = genre;
            this.ISBN = ISBN;
            Status = status;
            
        }
        public Book() { } // konstruktor domyślny

        public Book(Book bookToCopy) // konstruktor kopiujący
        {
            this.BookID = bookToCopy.BookID;
            this.BookTitle = bookToCopy.BookTitle;
            this.BookAuthor = bookToCopy.BookAuthor;
            this.Genre = bookToCopy.Genre;
            this.ISBN = bookToCopy.ISBN;
            this.Status = bookToCopy.Status;
        }

    }
}
