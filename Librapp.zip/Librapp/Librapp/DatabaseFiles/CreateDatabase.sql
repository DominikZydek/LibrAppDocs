-- Tworzenie tabeli Books
CREATE TABLE Books (
    BookID INT PRIMARY KEY,
    BookTitle VARCHAR(255) NOT NULL,
    BookAuthor VARCHAR(255) NOT NULL,
    Genre VARCHAR(50),
    ISBN VARCHAR(20) NOT NULL
);

-- Tworzenie tabeli Users
CREATE TABLE Users (
    UserID INT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Surname VARCHAR(50) NOT NULL,
    Login VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    Password VARCHAR(50) NOT NULL
);

-- Tworzenie tabeli Administrators
CREATE TABLE Administrators (
    AdminID INT PRIMARY KEY,
    JobTitle VARCHAR(50) NOT NULL,
    Name VARCHAR(50) NOT NULL,
    Surname VARCHAR(50) NOT NULL,
    Login VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    Password VARCHAR(50) NOT NULL
);

-- Tworzenie tabeli Borrowings
CREATE TABLE Borrowings (
    BorrowingID INT PRIMARY KEY,
    UserID INT,
    AdminID INT,
    BookID INT,
    BorrowingDate DATE,
    DueDate DATE,
    Status TEXT CHECK (Status IN ('Borrowed', 'Returned', 'Overdue')) NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (AdminID) REFERENCES Administrators(AdminID),
    FOREIGN KEY (BookID) REFERENCES Books(BookID)
);
