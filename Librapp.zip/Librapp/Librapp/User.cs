﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Librapp
{
    public class User
    {
        public int UserID { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Login { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public double Fees { get; set; }
        public int BorrowedBooks { get; set; }
        public int ReservedBooks { get; set; }

        public User(int userID, string name, string surname, string login, string email, string password, double fees, int borrowedBooks, int reservedBooks) // konstruktor
        {
            UserID = userID;
            Name = name;
            Surname = surname;
            Login = login;
            Email = email;
            Password = password;
            Fees = fees;
            BorrowedBooks = borrowedBooks;
            ReservedBooks = reservedBooks;
        }
        public User() { } // konstruktor domyślny

        public User(User userToCopy) // konstruktor kopiujący
        {
            this.UserID = userToCopy.UserID;
            this.Name = userToCopy.Name;
            this.Surname = userToCopy.Surname;
            this.Login = userToCopy.Login;
            this.Email = userToCopy.Email;
            this.Password = userToCopy.Password;
            this.Fees = userToCopy.Fees;
            this.BorrowedBooks = userToCopy.BorrowedBooks;
            this.ReservedBooks = userToCopy.ReservedBooks;
        }

    }
}
