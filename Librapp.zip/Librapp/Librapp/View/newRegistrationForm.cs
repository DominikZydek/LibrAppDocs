﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Text.RegularExpressions;
using System.Data.SQLite;
using System.IO;
using Librapp.Components;

namespace Librapp.View
{
    internal class newRegistrationForm 
    {
        
        internal bool NameValidation(TextBox MyTextBox)
        {
            if (string.IsNullOrEmpty(MyTextBox.Text))
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(MyTextBox, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(MyTextBox, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź imię";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else
            {
                Validation.ClearInvalid(MyTextBox.GetBindingExpression(TextBox.TextProperty));
                return true;
            }
        }

        internal bool SurnameValidation(TextBox MyTextBox)
        {
            if (string.IsNullOrEmpty(MyTextBox.Text))
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(MyTextBox, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(MyTextBox, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź nazwisko";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else
            {
                Validation.ClearInvalid(MyTextBox.GetBindingExpression(TextBox.TextProperty));
                return true;
            }
        }

        internal bool EmailValidation(TextBox MyTextBox, TextBox reEmail)
        {
            if (string.IsNullOrEmpty(MyTextBox.Text))
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(MyTextBox, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(MyTextBox, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź e-mail";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else if (!Regex.IsMatch(MyTextBox.Text,
                   @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z",
                    RegexOptions.IgnoreCase))
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(MyTextBox, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(MyTextBox, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź poprawny adres e-mail";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else if (IsInUse(MyTextBox.Text) == true)
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(MyTextBox, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(MyTextBox, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Podany adres e-mail jest już w użyciu";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else
            {
                Validation.ClearInvalid(MyTextBox.GetBindingExpression(TextBox.TextProperty));
                return true;
            }
        }
            
        internal bool reEmailValidation(TextBox reEMail, TextBox Email)
        {
            if (string.IsNullOrEmpty(reEMail.Text))
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(reEMail, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(reEMail, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź ponownie e-mail";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else if (reEMail.Text != Email.Text)
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(reEMail, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(reEMail, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Podane adresy e-mail nie są jednakowe";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else
            {
                Validation.ClearInvalid(reEMail.GetBindingExpression(TextBox.TextProperty));
                return true;
            }
        }

        internal bool PasswordValidations(PasswordValidation Passwd)
        {
            if (string.IsNullOrEmpty(Passwd.Password))
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(Passwd, PasswordValidation.PasswordProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(Passwd, PasswordValidation.PasswordProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź hasło";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else
            {
                Validation.ClearInvalid(Passwd.GetBindingExpression(PasswordValidation.PasswordProperty));
                return true;
            }
        }

        internal bool rePasswordValidations(PasswordValidation rePasswd, PasswordValidation Passwd)
        {
            if (string.IsNullOrEmpty(rePasswd.Password))
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(rePasswd, PasswordValidation.PasswordProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(rePasswd, PasswordValidation.PasswordProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź ponownie hasło";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else if(rePasswd.Password != Passwd.Password)
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(rePasswd, PasswordValidation.PasswordProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(rePasswd, PasswordValidation.PasswordProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Hasła nie są jednakowe";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else
            {
                Validation.ClearInvalid(rePasswd.GetBindingExpression(PasswordValidation.PasswordProperty));
                return true;
            }
        }
        private SQLiteConnection Connection() 
        {
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            try
            {
                sqlite_conn.Open();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }

            return sqlite_conn;
        }

        private bool IsInUse(string email)
        {
            bool value = false;
            SQLiteConnection inUse;
            inUse = Connection();

            SQLiteCommand cmds;
            cmds = inUse.CreateCommand();
            cmds.CommandText = ("SELECT EXISTS (SELECT * from Users Where Email='" + email + "')");

            SQLiteDataReader reader = cmds.ExecuteReader();
            while (reader.Read())
            {
                value = reader.GetBoolean(0);
            }

            return value;
        }
    }
}
