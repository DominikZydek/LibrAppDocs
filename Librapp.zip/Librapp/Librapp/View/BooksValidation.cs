﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;

namespace Librapp.View
{
    internal class BooksValidation
    {     
        internal bool BookTitleValidation(TextBox MyTextBox)
        {
            if (string.IsNullOrEmpty(MyTextBox.Text))
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(MyTextBox, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(MyTextBox, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź tytuł";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else
            {
                Validation.ClearInvalid(MyTextBox.GetBindingExpression(TextBox.TextProperty));
                return true;
            }
        }

        internal bool AuthorValidation(TextBox MyTextBox)
        {
            if (string.IsNullOrEmpty(MyTextBox.Text))
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(MyTextBox, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(MyTextBox, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź autora";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else
            {
                Validation.ClearInvalid(MyTextBox.GetBindingExpression(TextBox.TextProperty));
                return true;
            }
        }

        internal bool GenreValidation(TextBox MyTextBox)
        {
            if (string.IsNullOrEmpty(MyTextBox.Text))
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(MyTextBox, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(MyTextBox, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź gatunek";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else
            {
                Validation.ClearInvalid(MyTextBox.GetBindingExpression(TextBox.TextProperty));
                return true;
            }
        }
        internal bool ISBNValidation(TextBox MyTextBox)
        {
            if (string.IsNullOrEmpty(MyTextBox.Text))
            {
                BindingExpression bindingExpression =
                    BindingOperations.GetBindingExpression(MyTextBox, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(MyTextBox, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź numer ISBN";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else if(!Regex.IsMatch(MyTextBox.Text,
                @"^\d{9}[\d|X]$"))
            {
                BindingExpression bindingExpression =
                   BindingOperations.GetBindingExpression(MyTextBox, TextBox.TextProperty);

                BindingExpressionBase bindingExpressionBase =
                    BindingOperations.GetBindingExpressionBase(MyTextBox, TextBox.TextProperty);

                ValidationError validationError =
                    new ValidationError(new ExceptionValidationRule(), bindingExpression);

                validationError.ErrorContent = "Wprowadź poprawny number ISBN";

                Validation.MarkInvalid(bindingExpressionBase, validationError);
                return false;
            }
            else
            {
                Validation.ClearInvalid(MyTextBox.GetBindingExpression(TextBox.TextProperty));
                return true;
            }
        }
    }
}
