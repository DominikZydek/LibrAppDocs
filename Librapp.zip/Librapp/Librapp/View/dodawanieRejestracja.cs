﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.ComponentModel;
using System.Collections;
using System.Text.RegularExpressions;
using System.Runtime.CompilerServices;
using System.Windows.Forms.VisualStyles;
using System.Windows.Controls;
using System.Windows;
using System.Data.SQLite;
using System.IO;

namespace Librapp.View
{
    public class dodawanieRejestracja : IDataErrorInfo
    {

        private string Name;
        private string Surname;

        private string Email;
        private string reEmail;

        private string Password;
        private string rePassword;


        public string name
        {
            get { return Name; }
            set {
                Name = value;
            }
        }
        public string surname
        {
            get { return Surname; }
            set { Surname = value; }
        }

        public string email
        {
            get { return Email; }
            set { Email = value; }
        }

        public string reemail
        {
            get { return reEmail; }
            set { reEmail = value; }
        }

        public string password
        {
            get { return Password; }
            set { Password = value; }
        }

        public string repassword
        {
            get { return rePassword; }
            set { rePassword = value; }
        }

        #region IDataErrorInfo Members

        string IDataErrorInfo.Error
        {
            get { return string.Empty; }
        }

        public bool HasError { get; set; } = false;


    string IDataErrorInfo.this[string columnName]
        {
            get
            {
                if (columnName == "name")
                {
                    if (string.IsNullOrEmpty(Name))
                        return "Podaj imię";
                   
                }

                else if (columnName == "surname")
                {
                    if (string.IsNullOrEmpty(Surname))
                        return "Podaj nazwisko";
                }
                
                else if (columnName == "email")
                {
                    if (string.IsNullOrEmpty(Email))
                    {
                        return "Podaj adres e-mail";
                    }
                    else if (!Regex.IsMatch(Email,
                   @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z",
                    RegexOptions.IgnoreCase))
                    {
                        return "Podano niewłaściwy adres e-mail";
                    }
                    else if (IsInUse(Email) == true)
                    {
                        return "Podany e-mail jest już w użyciu";
                    }
                }
                else if (columnName == "reemail")
                {
                    if(string.IsNullOrEmpty(reEmail))
                    {
                        return "Podaj ponownie e-mail";
                    }
                    else if(reEmail != Email)
                    {
                        return "Podane adresy e-mail nie są jednakowe";
                    }
                }
                else if (columnName == "password")
                {
                    if(string.IsNullOrEmpty (Password))
                    {
                        return "Podaj hasło";
                    }
                }
                else if(columnName == "repassword")
                {
                    if(string.IsNullOrEmpty(rePassword))
                    {
                        return "Podaj ponownie hasło";
                    }
                    else if(Password != rePassword)
                    {
                        return "Hasła muszą być jednakowe!";
                    }
                }

                return null;
            }
        }
        #endregion

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            try
            {
                sqlite_conn.Open();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }

            return sqlite_conn;
        }

        private bool IsInUse(string email)
        {
            bool value = false;
            SQLiteConnection inUse;
            inUse = Connection();

            SQLiteCommand cmds;
            cmds = inUse.CreateCommand();
            cmds.CommandText = ("SELECT EXISTS (SELECT * from Users Where Email='" + email + "')");

            SQLiteDataReader reader = cmds.ExecuteReader();
            while(reader.Read())
            {
                value = reader.GetBoolean(0);
            }

            return value;
        }
    }
}
