﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SQLite;
using Path = System.IO.Path;
using System.Data.SqlClient;
using System.Data;
using System.Data.Entity;
using Librapp.MVVM.View;
using Librapp.MVVM.ViewModel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Librapp.View
{
    /// <summary>
    /// Logika interakcji dla klasy LoginMenu.xaml
    /// </summary>
    public partial class LoginMenu : Window
    {
        public LoginMenu()
        {
            InitializeComponent();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
            //pozwala przesuwać okno logowania gdziekolwiek klikniemy myszką
        }

        private void btnMinimize_Click(object sender, RoutedEventArgs e) //minimalizuje okno logowania
        {
            WindowState = WindowState.Minimized;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e) //zamyka okno logowania
        {
            Application.Current.Shutdown();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            SQLiteConnection loginConn;
            loginConn = Connection();

            SQLiteCommand cmds;
            cmds = loginConn.CreateCommand();

            string email = txtUser.Text;
            string password = txtPassword.Password;
            string login = txtUser.Text;

            if (txtUser.Text == "" || txtPassword.Password == "")
            {
                MessageBox.Show("Jedno z pól jest puste", "Błąd");
            }
            else
            {
                cmds.CommandText = ("Select * from Users where Email= '" + email + "' or Login = '" + login
                    + "'  and Password='" + password + "'");

                SQLiteDataAdapter da = new SQLiteDataAdapter(cmds);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    User loggedUser = new User
                    {
                        UserID = (int)dt.Rows[0]["UserID"],
                        Name = (string)dt.Rows[0]["Name"],
                        Surname = (string)dt.Rows[0]["Surname"],
                        Login = (string)dt.Rows[0]["Login"],
                        Email = (string)dt.Rows[0]["Email"],
                        Password = (string)dt.Rows[0]["Password"],
                        Fees = Convert.ToDouble(dt.Rows[0]["Fees"]),
                        BorrowedBooks = Convert.ToInt32(dt.Rows[0]["BorrowedBooks"]),
                        ReservedBooks = Convert.ToInt32(dt.Rows[0]["ReservedBooks"])
                    };

                    LoginInfo.LoggedUser = loggedUser;
                    
                    NewMainUserPanel newMainUserPanel = new NewMainUserPanel();
                    newMainUserPanel.Show();
                    ;
                    if (Window.GetWindow(this) != null)
                    {
                        Window.GetWindow(this).Close();
                    }
                }
                else
                {
                    MessageBox.Show("Błędny e-mail lub hasło.", "Błąd");
                }
            }
            loginConn.Close();
        }


        private void btnAdminLogin_Click(object sender, RoutedEventArgs e) //przycisk zaloguj jako admin
        {
           

            SQLiteConnection loginConn;
            loginConn = Connection();

            SQLiteCommand cmds;
            cmds = loginConn.CreateCommand();

            string email = txtUser.Text;
            string password = txtPassword.Password;
            string login = txtUser.Text;

            if (txtUser.Text == "" || txtPassword.Password == "")
            {
                MessageBox.Show("Jedno z pól jest puste", "Błąd");
            }
            else
            {
                cmds.CommandText = ("Select * from Administrators where Email= '" + email + "' or Login = '" + login
                    + "'  and Password='" + password + "'");

                SQLiteDataAdapter da = new SQLiteDataAdapter(cmds);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    Administrator loggedAdmin = new Administrator
                    {
                        AdminID = (int)dt.Rows[0]["AdminID"],
                        JobTitle = (string)dt.Rows[0]["JobTitle"],
                        Name = (string)dt.Rows[0]["Name"],
                        Surname = (string)dt.Rows[0]["Surname"],
                        Login = (string)dt.Rows[0]["Login"],
                        Email = (string)dt.Rows[0]["Email"],
                        Password = (string)dt.Rows[0]["Password"]
                    };
                    LoginInfo.LoggedAdmin = loggedAdmin;

                    NewAdminPanel newAdminPanel = new NewAdminPanel();
                    newAdminPanel.Show();
                    if (Window.GetWindow(this) != null)
                    {
                        Window.GetWindow(this).Close();
                    }
                }
                else
                {
                    MessageBox.Show("Błędny e-mail lub hasło.", "Błąd");
                }
            }
            loginConn.Close();

        }
        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            try
            {
                sqlite_conn.Open();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }

            return sqlite_conn;
        }


        private void btnRegistrate_Click(object sender, RoutedEventArgs e) //przycisk zarejestruj
        {
            Registration zarejestruj = new Registration();
            zarejestruj.Show();
            this.Close();
        }

        private void btnMaximize_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Normal)
                this.WindowState = WindowState.Maximized;
            else this.WindowState = WindowState.Normal;
        }
    }
}
