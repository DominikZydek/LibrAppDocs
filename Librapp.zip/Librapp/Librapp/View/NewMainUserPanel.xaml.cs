﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Runtime.InteropServices;
using System.Windows.Interop;
using System.Windows.Threading;
using System.Security.Principal;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Librapp.View
{
    /// <summary>
    /// Logika interakcji dla klasy NewMainUserPanel.xaml
    /// </summary>
    public partial class NewMainUserPanel : Window
    {
        //zegar
        private DispatcherTimer timer;
        private void Timer_Tick(object sender, EventArgs e)
        {
            // Aktualizacja tekstu zegara przy każdym ticku timera
            dateText.Text = DateTime.Now.ToString("yyyy-MM-dd");
            clockText.Text = DateTime.Now.ToString("HH:mm:ss");
        }


       
        public NewMainUserPanel()
        {
            InitializeComponent();
            usernameText.Text = $"Witaj, {LoginInfo.LoggedUser.Name}";
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1); // Interwał co sekundę
            timer.Tick += Timer_Tick;
            timer.Start();

            

        }
        
        [DllImport("user32.dll")]
        public static extern IntPtr SendMessage(IntPtr hWnd, int wMsg, int wParam, int lParam);
        

        private void pnlControlBar_MouseEnter(object sender, MouseEventArgs e)
        {
            this.MaxHeight = SystemParameters.MaximizedPrimaryScreenHeight;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnMinimize_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void btnMaximize_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Normal)
                this.WindowState = WindowState.Maximized;
            else this.WindowState = WindowState.Normal;
        }

        private void pnlControlBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                WindowInteropHelper helper = new WindowInteropHelper(this);
                SendMessage(helper.Handle, 161, 2, 0);
            }
        }

        private void btnLogOut_Click(object sender, RoutedEventArgs e)
        {
            LoginMenu loginMenu = new LoginMenu();
            loginMenu.Show();
            if (Window.GetWindow(this) != null)
            {
                Window.GetWindow(this).Close();
            }
        }
    }
}
