﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Librapp.View
{
    /// <summary>
    /// Logika interakcji dla klasy AdminView.xaml
    /// </summary>
    public partial class AdminView : Window
    {
        public AdminView()
        {
            InitializeComponent();
            txtDate.Text = DateTime.Now.ToString();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();

        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnMinimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnMaximize_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Normal)
                this.WindowState = WindowState.Maximized;
            else this.WindowState = WindowState.Normal;

        }

        private void btnDodajUzytkownika_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDodajKsiazke_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnWypozycz_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnZwrot_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnKatalog_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnCos_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
