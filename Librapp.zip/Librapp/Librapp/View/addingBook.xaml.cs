﻿using Librapp.MVVM.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Path = System.IO.Path;

namespace Librapp.View
{
    /// <summary>
    /// Logika interakcji dla klasy addingBook.xaml
    /// </summary>
    public partial class addingBook : Window
    {
        public addingBook()
        {
            InitializeComponent();
        }

        private void Dodaj(object sender, RoutedEventArgs e)
        {

            int BookID = GettingBookID() + 1;
            BooksValidation validation = new BooksValidation();
            bool ctr2 = validation.BookTitleValidation(BookTitle);
            bool ctr3 = validation.AuthorValidation(BookAuthor);
            bool ctr4 = validation.GenreValidation(Genre);
            bool ctr5 = validation.ISBNValidation(ISBN);

            if (ctr2 == true && ctr3 == true &&
                 ctr4 == true && ctr5 == true)
            {

                SQLiteConnection conn = Connection();
                SQLiteCommand cmd = conn.CreateCommand();
                try
                {
                    cmd.CommandText = "Insert into Books(BookID, BookTitle, BookAuthor, Genre, ISBN, Status)" +
                    "VALUES (" + BookID + ", '" + BookTitle.Text + "', '" + BookAuthor.Text + "', '" +
                    Genre.Text + "', '" + ISBN.Text + "', '" + "Available" + "')";

                    cmd.ExecuteNonQuery();


                    MessageBox.Show("Dodano nową pozycję", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch
                {
                    MessageBox.Show("Spróbuj ponownie", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }

        }

        private void Resetuj(object sender, RoutedEventArgs e)
        {
            BookTitle.Text = "";
            BookAuthor.Text = "";
            Genre.Text = "";
            ISBN.Text = "";
        }

        private void Anuluj(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private int GettingBookID()
        {
            int ID = 0;
            SQLiteConnection GetIDConn;
            GetIDConn = Connection();


            SQLiteCommand command;
            command = GetIDConn.CreateCommand();

            command.CommandText = ("SELECT BookID FROM Books ORDER BY BookID DESC LIMIT 1");

            SQLiteDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ID = reader.GetInt32(0);
            }
            GetIDConn.Close();
            return ID;
        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();

            return sqlite_conn;
        }
    }
}
