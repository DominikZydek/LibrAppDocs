﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms.VisualStyles;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using Path = System.IO.Path;

namespace Librapp.View
{
    /// <summary>
    /// Logika interakcji dla klasy Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)//do przesuwania okna
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void btnMinimize_Click(object sender, RoutedEventArgs e)//minimalizuje okno
        {
            WindowState = WindowState.Minimized;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)//zamyka okno
        {
            Application.Current.Shutdown();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e) //powrót do strony logowania
        {
            LoginMenu loginMenu = new LoginMenu();
            loginMenu.Show();
            this.Close();
        }

        private void btnRegistrate_Click(object sender, RoutedEventArgs e) //przycisk zarejestruj się 
        {
            LoginMenu loginMenu = new LoginMenu();

            int id = GettingID();
            id++;

            newRegistrationForm form = new newRegistrationForm();
            bool ctr1 = form.NameValidation(txtName);
            bool ctr2 = form.SurnameValidation(txtSurname);
            bool ctr3 = form.EmailValidation(txtMail, txtEmail2);
            bool ctr4 = form.reEmailValidation(txtEmail2, txtMail);
            bool ctr5 = form.PasswordValidations(txtPassword);
            bool ctr6 = form.rePasswordValidations(txtPassword2, txtPassword);



            if (ctr1 == true && ctr2 == true && ctr3 == true &&
                ctr4 == true && ctr5 == true && ctr6 == true)
            {
                string username = txtMail.Text.Substring(0, txtMail.Text.IndexOf("@"));
                //username = Username(username);


                SQLiteConnection registerConn;
                registerConn = Connection();
                SQLiteCommand cmd;
                cmd = registerConn.CreateCommand();

                try
                {
                    cmd.CommandText = ("Insert into Users (UserID, Name, Surname, Login, Email, Password)" +
                    "VALUES(" + id + ",'" + txtName.Text + "','" + txtSurname.Text + "','" + username + "','"
                    + txtMail.Text + "','" + txtPassword.Password + "')");
                    cmd.ExecuteNonQuery();
                }
                catch
                {
                    MessageBox.Show("Spróbuj ponownie", "Błąd", MessageBoxButton.OK);
                    registerConn.Close();
                    loginMenu.Show();
                    this.Close();
                }

                MessageBox.Show("Zarejestrowano pomyślnie\nTwoja nazwa użytkownika to: " + username);
                registerConn.Close();

                loginMenu.Show();
                this.Close();
            }

        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            try
            {
                sqlite_conn.Open();
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }

            return sqlite_conn;
        }

        private int GettingID()
        {
            int ID = 0;
            SQLiteConnection GetIDConn;
            GetIDConn = Connection();


            SQLiteCommand command;
            command = GetIDConn.CreateCommand();

            command.CommandText = ("SELECT UserID FROM Users ORDER BY UserID DESC LIMIT 1");

            SQLiteDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ID = reader.GetInt32(0);
            }
            GetIDConn.Close();
            return ID;
        }

        private string Username(string user)
        {
            SQLiteConnection sQLite;
            sQLite = Connection();

            SQLiteCommand comm;
            comm = sQLite.CreateCommand();

            comm.CommandText = ("SELECT EXISTS(SELECT * FROM Users WHERE Login = '" + user + "')");

            SQLiteDataReader reader = comm.ExecuteReader();

            if (reader.Read() == true)
            {
                sQLite.Close();
                return user + "_";
            }
            else
            {
                sQLite.Close();
                return user;
            }

        }
    }
}
