﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Librapp
{
    // klasa do użytku w obsłudze rezerwacji
    public class JoinedBookReservation
    {
        public int ReservationID { get; set; }
        public int BookID { get; set; }
        public string BookTitle { get; set; }
        public string BookAuthor { get; set; }
        public DateTime ReservationDate { get; set; }
        public DateTime ExpirationDate { get; set; }

        public JoinedBookReservation(int reservationID, int bookID, string bookTitle, string bookAuthor, DateTime reservationDate, DateTime expirationDate)
        {
            ReservationID = reservationID;
            BookID = bookID;
            BookTitle = bookTitle;
            BookAuthor = bookAuthor;
            ReservationDate = reservationDate;
            ExpirationDate = expirationDate;
        }
    }
}
