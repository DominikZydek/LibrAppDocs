﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Librapp
{
    // klasa do użytku w obsłudze wypożyczeń
    public class JoinedBookBorrowing
    {
        public int BorrowingID { get; set; }
        public int BookID { get; set; }
        public string BookTitle { get; set; }
        public string BookAuthor { get; set; }
        public DateTime BorrowingDate { get; set; }
        public DateTime DueDate { get; set; }

        public JoinedBookBorrowing(int borrowingID, int bookID, string bookTitle, string bookAuthor, DateTime borrowingDate, DateTime dueDate)
        {
            BorrowingID = borrowingID;
            BookID = bookID;
            BookTitle = bookTitle;
            BookAuthor = bookAuthor;
            BorrowingDate = borrowingDate;
            DueDate = dueDate;
        }
    }
}
