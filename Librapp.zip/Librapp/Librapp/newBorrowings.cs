﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Librapp
{
    public class newBorrowing
    {
        public int BorrowingID { get; set; }
        public string Login { get; set; }
        public string BookTitle { get; set; }
        public string BookAuthor { get; set; }
        public DateTime BorrowingDate { get; set; }
        public DateTime DueDate { get; set; }

        public newBorrowing(int borrowingID, string login, string bookTitle, string bookAuthor, 
            DateTime borrowingDate, DateTime dueDate)
        {
            BorrowingID = borrowingID;
            Login = login;
            BookTitle = bookTitle;
            BookAuthor = bookAuthor;
            BorrowingDate = borrowingDate;
            DueDate = dueDate;
        }
    }
}
