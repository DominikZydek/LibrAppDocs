﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Librapp
{
    // Przechowuje informacje o aktualnie zalogowanym użytkowniku
    public static class LoginInfo
    {
        public static User LoggedUser { get; set; }
        public static Administrator LoggedAdmin { get; set; }
    }
}
