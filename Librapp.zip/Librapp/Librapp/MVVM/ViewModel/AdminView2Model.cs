﻿using Librapp.Core;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SQLite;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Librapp.MVVM.ViewModel
{
    internal class AdminView2Model : ObservableObject
    {
        private ObservableCollection<User> _users;
        public ObservableCollection<User> Users
        {
            get { return _users; }
            set
            {
                _users = value;
                onPropertyChanged(nameof(Users));
            }
        }
        public ICommand LoadDataCommand { get; private set; }

        public AdminView2Model()
        {
            LoadDataCommand = new RelayCommand(LoadData);
        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }

        public void LoadData(object parameter)
        {
            Users = new ObservableCollection<User>();
            SQLiteConnection conn = Connection();

            SQLiteCommand cmds = conn.CreateCommand();

            cmds.CommandText = "Select * from Users;";

            SQLiteDataAdapter da = new SQLiteDataAdapter(cmds);
            DataTable dt = new DataTable();
            da.Fill(dt);

            foreach (DataRow row in dt.Rows)
            {
                int userID = (int)row["UserID"];
                string name = (string)row["Name"];
                string surname = (string)row["Surname"];
                string login = (string)row["Login"];
                string email = (string)row["Email"];
                string password = (string)row["Password"];
                decimal fees = (decimal)row["Fees"];
                long borrowedBooks = (long)row["BorrowedBooks"];
                long reservedBooks = (long)row["ReservedBooks"];


                Users.Add(new User(userID, name, surname, login, email, password, Convert.ToDouble(fees), 
                    Convert.ToInt32(borrowedBooks), Convert.ToInt32(reservedBooks)));
            }
            conn.Close();
        }
    }
}
