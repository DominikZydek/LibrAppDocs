﻿using Librapp.Core;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SQLite;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Librapp.MVVM.ViewModel
{
    internal class AdminView3Model : ObservableObject
    {
        private ObservableCollection<newBorrowing> _borrowings;
        public ObservableCollection<newBorrowing> Borrowings
        {
            get { return _borrowings; }
            set
            {
                _borrowings = value;
                onPropertyChanged(nameof(Borrowings));
            }
        }
        public ICommand LoadDataCommand { get; private set; }

        public AdminView3Model()
        {
            LoadDataCommand = new RelayCommand(LoadData);
        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }

        public void LoadData(object parameter)
        {
            Borrowings = new ObservableCollection<newBorrowing>();
            SQLiteConnection conn = Connection();

            SQLiteCommand cmds = conn.CreateCommand();

            cmds.CommandText = "SELECT  BorrowingID, Login, BookTitle, BookAuthor, BorrowingDate, " +
                "DueDate from Borrowings inner join Users on Borrowings.UserID = Users.UserID " +
                "inner join Books on Borrowings.BookID = Books.BookID";

            SQLiteDataAdapter da = new SQLiteDataAdapter(cmds);
            DataTable dt = new DataTable();
            da.Fill(dt);

            foreach (DataRow row in dt.Rows)
            {
                int borrowingID = (int)row["BorrowingID"];
                string Login = (string)row["Login"];
                string BookTitle = (string)row["BookTitle"];
                string BookAuthor = (string)row["BookAuthor"];
                DateTime borrowingDate = (DateTime)row["BorrowingDate"];
                DateTime dueDate = (DateTime)row["DueDate"];


                Borrowings.Add(new newBorrowing(borrowingID, Login, BookTitle, BookAuthor, borrowingDate, dueDate));
            }
            conn.Close();
        }
    }
}
