﻿using Librapp.Core;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Librapp.MVVM.ViewModel
{
    internal class View2Model : ObservableObject
    {
        private ObservableCollection<JoinedBookBorrowing> _borrowedBooks;
        public ObservableCollection<JoinedBookBorrowing> BorrowedBooks
        {
            get { return _borrowedBooks; }
            set
            {
                _borrowedBooks = value;
                onPropertyChanged(nameof(BorrowedBooks));
            }
        }

        public ICommand LoadDataCommand { get; private set; }

        public View2Model()
        {
            LoadDataCommand = new RelayCommand(LoadData);
        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }

        private void LoadData(object parameter)
        {
            BorrowedBooks = new ObservableCollection<JoinedBookBorrowing>();
            SQLiteConnection getBooks;
            getBooks = Connection();

            SQLiteCommand cmds;
            cmds = getBooks.CreateCommand();

            cmds.CommandText = $"select Borrowings.BorrowingID, Borrowings.BookID, Books.BookTitle, Books.BookAuthor, Borrowings.BorrowingDate, Borrowings.DueDate from Books join Borrowings on Borrowings.BookID = Books.BookID where Borrowings.UserID = {LoginInfo.LoggedUser.UserID}";

            SQLiteDataAdapter da = new SQLiteDataAdapter(cmds);
            DataTable dt = new DataTable();
            da.Fill(dt);

            foreach (DataRow row in dt.Rows)
            {
                int borrowingId = (int)row["BorrowingID"];
                int bookId = (int)row["BookID"];
                string bookTitle = (string)row["BookTitle"];
                string bookAuthor = (string)row["BookAuthor"];
                DateTime borrowingDate = (DateTime)row["BorrowingDate"];
                DateTime dueDate = (DateTime)row["DueDate"];


                BorrowedBooks.Add(new JoinedBookBorrowing(borrowingId, bookId, bookTitle, bookAuthor, borrowingDate, dueDate));
            }
        }
    }
}
