﻿using Librapp.Core;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SQLite;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Input;

namespace Librapp.MVVM.ViewModel
{
    internal class View3Model : ObservableObject
    {
        private ObservableCollection<JoinedBookReservation> _reservedBooks;
        public ObservableCollection<JoinedBookReservation> ReservedBooks
        {
            get { return _reservedBooks; }
            set
            {
                _reservedBooks = value;
                onPropertyChanged(nameof(ReservedBooks));
            }
        }

        public ICommand LoadDataCommand { get; private set; }

        public View3Model()
        {
            LoadDataCommand = new RelayCommand(LoadData);
        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }

        private void LoadData(object parameter)
        {
            ReservedBooks = new ObservableCollection<JoinedBookReservation>();
            SQLiteConnection getBooks;
            getBooks = Connection();

            SQLiteCommand cmds;
            cmds = getBooks.CreateCommand();

            cmds.CommandText = $"select Reservations.ReservationID, Reservations.BookID, Books.BookTitle, Books.BookAuthor, Reservations.ReservationDate, Reservations.ExpirationDate " +
                $"from Books join Reservations on Reservations.BookID = Books.BookID where Reservations.UserID = {LoginInfo.LoggedUser.UserID}";

            SQLiteDataAdapter da = new SQLiteDataAdapter(cmds);
            DataTable dt = new DataTable();
            da.Fill(dt);

            foreach (DataRow row in dt.Rows)
            {
                int reservationId = (int)row["ReservationID"];
                int bookId = (int)row["BookID"];
                string bookTitle = (string)row["BookTitle"];
                string bookAuthor = (string)row["BookAuthor"];
                DateTime reservationDate = (DateTime)row["ReservationDate"];
                DateTime expirationDate = (DateTime)row["ExpirationDate"];


                ReservedBooks.Add(new JoinedBookReservation(reservationId, bookId, bookTitle, bookAuthor, reservationDate, expirationDate));
            }
        }
    }
}
