﻿using Librapp.Core;
using Librapp.View;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SQLite;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Documents;
using System.ComponentModel;
using System.Windows.Input;

namespace Librapp.MVVM.ViewModel
{
    internal class HomeViewModel : ObservableObject
    {
        private ObservableCollection<Book> _books;
        public ObservableCollection<Book> Books
        {
            get { return _books; }
            set
            {
                _books = value;
                onPropertyChanged(nameof(Books));
            }
        }
        public ICommand LoadDataCommand { get; private set; }

        public HomeViewModel()
        {
            LoadDataCommand = new RelayCommand(LoadData);
        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }

        public void LoadData(object parameter)
        {
            Books = new ObservableCollection<Book>();
            SQLiteConnection getBooks;
            getBooks = Connection();

            SQLiteCommand cmds;
            cmds = getBooks.CreateCommand();

            cmds.CommandText = "Select * from Books;";

            SQLiteDataAdapter da = new SQLiteDataAdapter(cmds);
            DataTable dt = new DataTable();
            da.Fill(dt);

            foreach (DataRow row in dt.Rows)
            {
                int bookId = (int)row["BookID"];
                string bookTitle = (string)row["BookTitle"];
                string bookAuthor = (string)row["BookAuthor"];
                string genre = (string)row["Genre"];
                string ISBN = (string)row["ISBN"];
                string status = "";
                if ((string)row["Status"] == "Available")
                {
                    status = "Dostępna";
                }
                else if ((string)row["Status"] == "Borrowed")
                {
                    status = "Wypożyczona";
                }
                else if ((string)row["Status"] == "Reserved")
                {
                    status = "Zarezerwowana";
                }

                Books.Add(new Book(bookId, bookTitle, bookAuthor, genre, ISBN, status));
            }
            getBooks.Close();
        }
    }

}
