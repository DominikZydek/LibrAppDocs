﻿using Librapp.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace Librapp.MVVM.ViewModel
{
    internal class View4Model : ObservableObject
    {
        private User _loggedUser;
        public User LoggedUser
        {
            get { return _loggedUser; }
            set
            {
                _loggedUser = value;
                onPropertyChanged(nameof(LoggedUser));
            }
        }

        public ICommand LoadDataCommand { get; private set; }

        public View4Model()
        {
            LoadDataCommand = new RelayCommand(LoadData);
        }

        private void LoadData(object parameter)
        {
            LoggedUser = new User
            {
                UserID = LoginInfo.LoggedUser.UserID,
                Name = LoginInfo.LoggedUser.Name,
                Surname = LoginInfo.LoggedUser.Surname,
                Login = LoginInfo.LoggedUser.Login,
                Email = LoginInfo.LoggedUser.Email,
                Password = LoginInfo.LoggedUser.Password,
                Fees = LoginInfo.LoggedUser.Fees,
                BorrowedBooks = LoginInfo.LoggedUser.BorrowedBooks,
                ReservedBooks = LoginInfo.LoggedUser.ReservedBooks,
            };
        }
    }
}
