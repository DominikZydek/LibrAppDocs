﻿using Librapp.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;

namespace Librapp.MVVM.ViewModel
{
    internal class MainViewModel:ObservableObject
    {



        public RelayCommand HomeViewCommand { get; set; }
        public RelayCommand View2Command { get; set; }
        public RelayCommand View3Command { get; set; }
        public RelayCommand View4Command { get; set; }

        public RelayCommand AdminHomeViewCommand { get; set; }
        public RelayCommand AdminView2Command { get; set; }
        public RelayCommand AdminView3Command { get; set; }
        public RelayCommand AdminView4Command { get; set; }


        public HomeViewModel HomeVm { get; set; }
        public View2Model View2VM { get; set; }
        public View3Model View3VM { get; set; }
        public View4Model View4VM { get; set; }

        //Admin

        public AdminViewModel AdminHomeVM { get; set; }
        public AdminView2Model AdminView2VM { get; set; }
        public AdminView3Model AdminView3VM { get; set; }
        public AdminView4Model AdminView4VM { get; set; }


        private object _currentView;
        public object CurrentView
        {
            get { return _currentView; }
            set
            {
                _currentView = value;
                onPropertyChanged();
            }
        }


        public MainViewModel()
        {

            HomeVm = new HomeViewModel();
            View2VM = new View2Model();
            View3VM = new View3Model();
            View4VM = new View4Model();
           //CurrentView=HomeVm;

            AdminHomeVM = new AdminViewModel();
            AdminView2VM = new AdminView2Model();
            AdminView3VM = new AdminView3Model();
            AdminView4VM = new AdminView4Model();

            HomeViewCommand = new RelayCommand(o =>
            {
                CurrentView = HomeVm;
            });

            View2Command = new RelayCommand(o =>
            {
                CurrentView = View2VM;
            });

            View3Command = new RelayCommand(o =>
            {
                CurrentView = View3VM;
            });
            View4Command = new RelayCommand(o =>
            {
                CurrentView = View4VM;
            });

            

            AdminHomeViewCommand = new RelayCommand(o =>
            {
                CurrentView = AdminHomeVM;
            });
            AdminView2Command = new RelayCommand(o =>
            {
                CurrentView = AdminView2VM;
            });
            AdminView3Command = new RelayCommand(o =>
            {
                CurrentView = AdminView3VM;
            });
            AdminView4Command = new RelayCommand(o =>
            {
                CurrentView = AdminView4VM;
            });

            if (LoginInfo.LoggedAdmin!=null)
            {
                CurrentView = AdminHomeVM;
            }
            else if (LoginInfo.LoggedUser!=null)
            {
                CurrentView = HomeVm;
            }


        }

    }
}
