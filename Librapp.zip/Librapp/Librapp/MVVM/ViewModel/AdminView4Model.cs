﻿using Librapp.Core;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SQLite;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Librapp.MVVM.ViewModel
{
    internal class AdminView4Model : ObservableObject
    {
        private ObservableCollection<newReservations> _reservations;
        public ObservableCollection<newReservations> Reservations
        {
            get { return _reservations; }
            set
            {
                _reservations = value;
                onPropertyChanged(nameof(Reservations));
            }
        }
        public ICommand LoadDataCommand { get; private set; }

        public AdminView4Model()
        {
            LoadDataCommand = new RelayCommand(LoadData);
        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }

        public void LoadData(object parameter)
        {
            Reservations = new ObservableCollection<newReservations>();
            SQLiteConnection conn = Connection();

            SQLiteCommand cmds = conn.CreateCommand();

            cmds.CommandText = "SELECT ReservationID, Login, BookTitle, BookAuthor, ReservationDate, ExpirationDate " +
                "from Reservations inner join Users on Reservations.UserID = Users.UserID " +
                "inner join Books on Reservations.BookID = Books.BookID ";

            SQLiteDataAdapter da = new SQLiteDataAdapter(cmds);
            DataTable dt = new DataTable();
            da.Fill(dt);

            foreach (DataRow row in dt.Rows)
            {
                int reservationID = (int)row["ReservationID"];
                string login = (string)row["Login"];
                string bookTitle = (string)row["BookTitle"];
                string bookAuthor = (string)row["BookAuthor"];
                DateTime reservationDate = (DateTime)row["ReservationDate"];
                DateTime expirationDate = (DateTime)row["ExpirationDate"];


                Reservations.Add(new newReservations(reservationID, login, bookTitle, bookAuthor
                     , reservationDate, expirationDate));
            }
            conn.Close();
        }
    }
}
