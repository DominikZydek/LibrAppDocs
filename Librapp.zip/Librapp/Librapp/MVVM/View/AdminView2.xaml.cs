﻿using Librapp.MVVM.ViewModel;
using Librapp.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Path = System.IO.Path;

namespace Librapp.MVVM.View
{
    /// <summary>
    /// Logika interakcji dla klasy AdminView2.xaml
    /// </summary>
    public partial class AdminView2 : UserControl
    {
        private AdminView2Model _viewModel;
        List<DataGridRow> list = new List<DataGridRow>();
        public AdminView2()
        {
            InitializeComponent();
            _viewModel = new AdminView2Model();
            DataContext = _viewModel;
            _viewModel.LoadDataCommand.Execute(null);
        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }

        private void Usun(object sender, RoutedEventArgs e)
        {
            IEditableCollectionView items = dataGrid.Items;

            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz usunąć użytkownika {((User)dataGrid.CurrentItem).Login}?",
                "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                if (items.CanRemove)
                {
                    SQLiteConnection conn = Connection();
                    SQLiteCommand cmd = conn.CreateCommand();

                    cmd.CommandText = "DELETE FROM Users WHERE UserID = " + ((User)dataGrid.CurrentItem).UserID;
                    cmd.ExecuteNonQuery();

                    _viewModel.LoadDataCommand.Execute(null);

                    conn.Close();

                    MessageBox.Show("Usunięto wybraną pozycję", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    System.Windows.MessageBox.Show("Nie można usunąć określonej pozycji", "Błąd",
                        System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
                }
            }

        }


        private void btnZatwierdz(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz zaktualizować wybranych użytkowników?",
                "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {

                SQLiteConnection conn = Connection();
                for (int i = 0; i < list.Count; i++)
                {
                    User usr = (User)list[i].Item;

                    SQLiteCommand cmd = conn.CreateCommand();


                    cmd.CommandText = $"UPDATE Users SET Name = '{usr.Name}', Surname = '{usr.Surname}',"
                    + $"Login = '{usr.Login}', Password = '{usr.Password}', Fees = {usr.Fees}, BorrowedBooks = " +
                    $"{usr.BorrowedBooks}, ReservedBooks = {usr.ReservedBooks} Where UserID = {usr.UserID}";

                    cmd.ExecuteNonQuery();

                }
                _viewModel.LoadDataCommand.Execute(null);

                MessageBox.Show("Zaktualizowano użytkownika", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            Zatwierdz.Visibility = Visibility.Collapsed;
            Anuluj.Visibility = Visibility.Collapsed;
            dataGrid.IsReadOnly = true;
        }

        private void btnAnuluj(object sender, RoutedEventArgs e)
        {
            Zatwierdz.Visibility = Visibility.Collapsed;
            Anuluj.Visibility = Visibility.Collapsed;
        }


        private void Modyfikuj(object sender, RoutedEventArgs e)
        {
            dataGrid.IsReadOnly = false;
            Zatwierdz.Visibility = Visibility.Visible;
            Anuluj.Visibility = Visibility.Visible;

        }

        private void dataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            var rowIndex = dataGrid.SelectedIndex;

            var row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(rowIndex);

            if (!list.Contains(row))
            {
                list.Add(row);
            }
        }
    }
}
