﻿using Librapp.Core;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SQLite;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.IO;
using Librapp.MVVM.ViewModel;

namespace Librapp.MVVM.View
{
    /// <summary>
    /// Logika interakcji dla klasy HomeView.xaml
    /// </summary>
    public partial class HomeView : UserControl
    {
        private HomeViewModel _viewModel;
        public HomeView()
        {
            InitializeComponent();
            _viewModel = new HomeViewModel();
            DataContext = _viewModel;
            _viewModel.LoadDataCommand.Execute(null);
        }

        private void WypozyczButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var book = button?.CommandParameter as Book;

            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz wypożyczyć pozycję {book.BookTitle}?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                if (LoginInfo.LoggedUser.BorrowedBooks >= 5)
                {
                    MessageBox.Show("Limit wypożyczeń został przekroczony", "Informacja");
                }
                else if (book.Status == "Dostępna")
                {
                    SQLiteConnection addBorrowing;
                    addBorrowing = Connection();

                    SQLiteCommand cmds = addBorrowing.CreateCommand();

                    int borrowingID = GettingBorrowingID() + 1;
                    int userID = LoginInfo.LoggedUser.UserID;
                    int bookID = book.BookID;
                    DateTime borrowingDate = DateTime.Now;
                    DateTime dueDate = borrowingDate.AddDays(14);
                    int borrowedBooksAfter = LoginInfo.LoggedUser.BorrowedBooks + 1;
                    LoginInfo.LoggedUser.BorrowedBooks = borrowedBooksAfter;

                    cmds.CommandText = ($"INSERT INTO Borrowings VALUES({borrowingID}, {userID}, {bookID}, DATE('{borrowingDate.ToString("yyyy-MM-dd")}'), DATE('{dueDate.ToString("yyyy-MM-dd")}'));" +
                        $"UPDATE Books SET Status = 'Borrowed' WHERE BookID = {bookID};" +
                        $"UPDATE Users SET BorrowedBooks = {borrowedBooksAfter} WHERE UserID = {userID};");
                    cmds.ExecuteNonQuery();

                    // odśwież view
                    _viewModel.LoadDataCommand.Execute(null);


                    addBorrowing.Close();
                    

                    MessageBox.Show("Potwierdzono");
                }
                else
                {
                    MessageBox.Show("Nie można wypożyczyć tej pozycji", "Informacja");
                }
            }

        }

        private void ZarezerwujButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var book = button?.CommandParameter as Book;

            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz zarezerwować książkę {book.BookTitle}?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                if (LoginInfo.LoggedUser.ReservedBooks >= 3)
                {
                    MessageBox.Show("Limit rezerwacji został przekroczony", "Informacja");
                }
                else if (book.Status == "Wypożyczona")
                {
                    SQLiteConnection getBorrowingInfo;
                    getBorrowingInfo = Connection();

                    SQLiteCommand cmds = getBorrowingInfo.CreateCommand();

                    cmds.CommandText = $"SELECT DueDate FROM Borrowings WHERE BookID = {book.BookID}";

                    SQLiteDataAdapter da = new SQLiteDataAdapter(cmds);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    DateTime expirationDate = ((DateTime)dt.Rows[0]["DueDate"]).AddDays(2);

                    getBorrowingInfo.Close();

                    SQLiteConnection addReservation;
                    addReservation = Connection();

                    SQLiteCommand cmds2 = addReservation.CreateCommand();

                    int reservationID = GettingReservationID() + 1;
                    int userID = LoginInfo.LoggedUser.UserID;
                    int bookID = book.BookID;
                    DateTime reservationDate = DateTime.Now;
                    int reservedBooksAfter = LoginInfo.LoggedUser.ReservedBooks + 1;
                    LoginInfo.LoggedUser.ReservedBooks = reservedBooksAfter;

                    cmds2.CommandText = ($"INSERT INTO Reservations VALUES({reservationID}, {userID}, {bookID}, DATE('{reservationDate.ToString("yyyy-MM-dd")}'), DATE('{expirationDate.ToString("yyyy-MM-dd")}'));" +
                        $"UPDATE Books SET Status = 'Reserved' WHERE BookID = {bookID};" +
                        $"UPDATE Users SET ReservedBooks = {reservedBooksAfter} WHERE UserID = {userID}");
                    cmds2.ExecuteNonQuery();

                    // odśwież view
                    _viewModel.LoadDataCommand.Execute(null);


                    addReservation.Close();

                    MessageBox.Show("Potwierdzono");
                }
                else 
                {
                    MessageBox.Show("Nie można zarezerwować tej pozycji", "Informacja");
                }
            }

        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }

        private int GettingBorrowingID()
        {
            int ID = 0;
            SQLiteConnection GetIDConn;
            GetIDConn = Connection();


            SQLiteCommand command;
            command = GetIDConn.CreateCommand();

            command.CommandText = ("SELECT BorrowingID FROM Borrowings ORDER BY BorrowingID DESC LIMIT 1");

            SQLiteDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ID = reader.GetInt32(0);
            }
            GetIDConn.Close();
            return ID;
        }

        private int GettingReservationID()
        {
            int ID = 0;
            SQLiteConnection GetIDConn;
            GetIDConn = Connection();


            SQLiteCommand command;
            command = GetIDConn.CreateCommand();

            command.CommandText = ("SELECT ReservationID FROM Reservations ORDER BY ReservationID DESC LIMIT 1");

            SQLiteDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ID = reader.GetInt32(0);
            }
            GetIDConn.Close();
            return ID;
        }

    }
}
