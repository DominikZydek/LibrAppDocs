﻿using Librapp.MVVM.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Librapp.MVVM.View
{
    /// <summary>
    /// Logika interakcji dla klasy View4.xaml
    /// </summary>
    public partial class View4 : UserControl
    {
        private View4Model _viewModel;
        public View4()
        {
            InitializeComponent();
            _viewModel = new View4Model();
            DataContext = _viewModel;
            _viewModel.LoadDataCommand.Execute(null);
        }

        private void btnEditLogin_Click(object sender, RoutedEventArgs e)
        {
            LoginTextBox.IsEnabled = true;
            btnEditLogin.Visibility = Visibility.Collapsed;
            btnSaveLogin.Visibility = Visibility.Visible;
        }

        private void btnEditPassword_Click(object sender, RoutedEventArgs e)
        {
            PasswordTextBox.IsEnabled = true;
            btnEditPassword.Visibility = Visibility.Collapsed;
            btnSavePassword.Visibility = Visibility.Visible;
        }

        private void btnEditEmail_Click(object sender, RoutedEventArgs e)
        {
            EmailTextBox.IsEnabled = true;
            btnEditEmail.Visibility = Visibility.Collapsed;
            btnSaveEmail.Visibility = Visibility.Visible;
        }

        private void btnSaveLogin_Click(object sender, RoutedEventArgs e)
        {
            LoginTextBox.IsEnabled = false;
            btnSaveLogin.Visibility = Visibility.Collapsed;
            btnEditLogin.Visibility = Visibility.Visible;
            // zapytaj o potwierdzenie
            // zapytanie sql
        }

        private void btnSavePassword_Click(object sender, RoutedEventArgs e)
        {
            PasswordTextBox.IsEnabled = false;
            btnSavePassword.Visibility = Visibility.Collapsed;
            btnEditPassword.Visibility = Visibility.Visible;
            // zapytaj o potwierdzenie
            // zapytanie sql
        }

        private void btnSaveEmail_Click(object sender, RoutedEventArgs e)
        {
            EmailTextBox.IsEnabled = false;
            btnSaveEmail.Visibility = Visibility.Collapsed;
            btnEditEmail.Visibility = Visibility.Visible;
            // zapytaj o potwierdzenie
            // zapytanie sql
        }

        private void btnPayFees_Click(object sender, RoutedEventArgs e)
        {
            // obsługa zapłaty opłat
        }

        private void btnSeeBorrowed_Click(object sender, RoutedEventArgs e)
        {
            // przejście do okna wypożyczenia
        }

        private void btnSeeReserved_Click(object sender, RoutedEventArgs e)
        {
            // przejście do okna zarezerwowane
        }
    }
}
