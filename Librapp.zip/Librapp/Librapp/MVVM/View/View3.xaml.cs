﻿using Librapp.MVVM.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace Librapp.MVVM.View
{
    /// <summary>
    /// Logika interakcji dla klasy View3.xaml
    /// </summary>
    public partial class View3 : UserControl
    {
        private View3Model _viewModel;
        public View3()
        {
            InitializeComponent();
            _viewModel = new View3Model();
            DataContext = _viewModel;
            _viewModel.LoadDataCommand.Execute(null);
        }

        private void WypozyczButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var joinedBookReservation = button?.CommandParameter as JoinedBookReservation;

            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz wypożyczyć pozycję {joinedBookReservation.BookTitle}?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                SQLiteConnection getBorrowingInfo;
                getBorrowingInfo = Connection();

                SQLiteCommand cmds = getBorrowingInfo.CreateCommand();

                cmds.CommandText = $"SELECT DueDate FROM Borrowings WHERE BookID = {joinedBookReservation.BookID}";

                SQLiteDataAdapter da = new SQLiteDataAdapter(cmds);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if ((DateTime)dt.Rows[0]["DueDate"] >= DateTime.Now)
                {
                    MessageBox.Show("Nie można jeszcze wypożyczyć tej pozycji", "Informacja");
                    getBorrowingInfo.Close();
                    _viewModel.LoadDataCommand.Execute(null);
                    return;
                }

                getBorrowingInfo.Close();

                SQLiteConnection addBorrowing;
                addBorrowing = Connection();

                SQLiteCommand cmds2 = addBorrowing.CreateCommand();

                int borrowingID = GettingBorrowingID() + 1;
                int reservationID = joinedBookReservation.ReservationID;
                int userID = LoginInfo.LoggedUser.UserID;
                int bookID = joinedBookReservation.BookID;
                DateTime borrowingDate = DateTime.Now;
                DateTime dueDate = borrowingDate.AddDays(14);
                int borrowedBooksAfter = LoginInfo.LoggedUser.BorrowedBooks + 1;
                int reservedBooksAfter = LoginInfo.LoggedUser.ReservedBooks - 1;
                LoginInfo.LoggedUser.BorrowedBooks = borrowedBooksAfter;
                LoginInfo.LoggedUser.ReservedBooks = reservedBooksAfter;

                cmds2.CommandText = ($"INSERT INTO Borrowings VALUES({borrowingID}, {userID}, {bookID}, DATE('{borrowingDate.ToString("yyyy-MM-dd")}'), DATE('{dueDate.ToString("yyyy-MM-dd")}'));" +
                    $"UPDATE Books SET Status = 'Borrowed' WHERE BookID = {bookID};" +
                    $"DELETE FROM Reservations WHERE ReservationID = {reservationID};" +
                    $"UPDATE Users SET BorrowedBooks = {borrowedBooksAfter}, ReservedBooks = {reservedBooksAfter} WHERE UserID = {userID}");
                cmds2.ExecuteNonQuery();

                // odśwież view
                _viewModel.LoadDataCommand.Execute(null);


                addBorrowing.Close();


                MessageBox.Show("Potwierdzono");
            }

        }

        private void UsunButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var joinedBookReservation = button?.CommandParameter as JoinedBookReservation;

            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz usunąć z Zarezerwowanych pozycję {joinedBookReservation.BookTitle}?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                SQLiteConnection deleteReservation;
                deleteReservation = Connection();

                SQLiteCommand cmds = deleteReservation.CreateCommand();

                int reservationID = joinedBookReservation.ReservationID;
                int userID = LoginInfo.LoggedUser.UserID;
                int reservedBooksAfter = LoginInfo.LoggedUser.ReservedBooks - 1;
                LoginInfo.LoggedUser.ReservedBooks = reservedBooksAfter;

                cmds.CommandText = ($"DELETE FROM Reservations WHERE ReservationID = {reservationID};" +
                    $"UPDATE Users SET ReservedBooks = {reservedBooksAfter} WHERE UserID = {userID};" +
                    $"UPDATE Books SET Status = 'Borrowed' WHERE BookID = {joinedBookReservation.BookID}") ;
                cmds.ExecuteNonQuery();

                // odśwież view
                _viewModel.LoadDataCommand.Execute(null);

                deleteReservation.Close();

                MessageBox.Show("Potwierdzono");
            }

        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }

        private int GettingBorrowingID()
        {
            int ID = 0;
            SQLiteConnection GetIDConn;
            GetIDConn = Connection();


            SQLiteCommand command;
            command = GetIDConn.CreateCommand();

            command.CommandText = ("SELECT BorrowingID FROM Borrowings ORDER BY BorrowingID DESC LIMIT 1");

            SQLiteDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ID = reader.GetInt32(0);
            }
            GetIDConn.Close();
            return ID;
        }
    }
}
