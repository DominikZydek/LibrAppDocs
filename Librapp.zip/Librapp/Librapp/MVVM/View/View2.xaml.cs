﻿using Librapp.MVVM.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace Librapp.MVVM.View
{
    /// <summary>
    /// Logika interakcji dla klasy View2.xaml
    /// </summary>
    public partial class View2 : UserControl
    {
        private View2Model _viewModel;
        public View2()
        {
            InitializeComponent();
            _viewModel = new View2Model();
            DataContext = _viewModel;
            _viewModel.LoadDataCommand.Execute(null);
        }

        private void ZwrocButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var joinedBookBorrowing = button?.CommandParameter as JoinedBookBorrowing;

            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz zwrócić pozycję {joinedBookBorrowing.BookTitle}?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {

                if (joinedBookBorrowing.DueDate < DateTime.Now)
                {
                    int daysPastDue = DateTime.Now.Subtract(joinedBookBorrowing.DueDate).Days;
                    double fee = daysPastDue * 0.5;

                    MessageBox.Show($"Przekroczono datę zwrotu o {daysPastDue} dni, nałożono karę: {fee:F2} zł", "Informacja");

                    // naliczanie kary
                }

                SQLiteConnection returnBook;
                returnBook = Connection();

                SQLiteCommand cmds = returnBook.CreateCommand();

                int borrowingID = joinedBookBorrowing.BorrowingID;
                int bookID = joinedBookBorrowing.BookID;
                int userID = LoginInfo.LoggedUser.UserID;
                int borrowedBooksAfter = LoginInfo.LoggedUser.BorrowedBooks - 1;
                LoginInfo.LoggedUser.BorrowedBooks = borrowedBooksAfter;

                cmds.CommandText = ($"UPDATE Books SET Status = 'Available' WHERE BookID = {bookID};" +
                    $"DELETE FROM Borrowings WHERE BorrowingID = {borrowingID};" +
                    $"UPDATE Users SET BorrowedBooks = {borrowedBooksAfter} WHERE UserID = {userID}");
                cmds.ExecuteNonQuery();

                // odśwież view
                _viewModel.LoadDataCommand.Execute(null);


                returnBook.Close();


                MessageBox.Show("Potwierdzono");
            }

        }

        private void PrzedluzButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var joinedBookBorrowing = button?.CommandParameter as JoinedBookBorrowing;

            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz przedłużyć zwrot pozycji {joinedBookBorrowing.BookTitle}?", "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                DateTime prolongedDate = joinedBookBorrowing.DueDate.AddDays(7);

                if (joinedBookBorrowing.DueDate < DateTime.Now)
                {
                    MessageBox.Show("Czas zwrotu minął", "Informacja");
                }
                // jeżeli już raz było przedłużane
                else if (prolongedDate.Subtract(joinedBookBorrowing.BorrowingDate).Days > 21)
                {
                    MessageBox.Show("Można przedłużyć zwrot tylko raz", "Informacja");
                }
                else
                {
                    SQLiteConnection prolongDueDate;
                    prolongDueDate = Connection();

                    SQLiteCommand cmds = prolongDueDate.CreateCommand();

                    int borrowingID = joinedBookBorrowing.BorrowingID;

                    cmds.CommandText = ($"UPDATE Borrowings SET DueDate = DATE('{prolongedDate.ToString("yyyy-MM-dd")}') WHERE BorrowingID = {borrowingID}");
                    cmds.ExecuteNonQuery();

                    // odśwież view

                    prolongDueDate.Close();

                    MessageBox.Show("Potwierdzono");
                }
            }

        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }
    }
}
