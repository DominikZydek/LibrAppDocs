﻿using Librapp.MVVM.ViewModel;
using Librapp.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MessageBox = System.Windows.MessageBox;
using Path = System.IO.Path;
using UserControl = System.Windows.Controls.UserControl;

namespace Librapp.MVVM.View
{
    /// <summary>
    /// Logika interakcji dla klasy AdminHomeView.xaml
    /// </summary>
    public partial class AdminHomeView : UserControl
    {
        private AdminViewModel _viewModel;
        List<DataGridRow> list = new List<DataGridRow>();

        public AdminHomeView()
        {
            InitializeComponent();
            _viewModel = new AdminViewModel();
            DataContext = _viewModel;
            _viewModel.LoadDataCommand.Execute(null);
        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }

        private void Usun(object sender, RoutedEventArgs e)
        {
            IEditableCollectionView items = dataGrid.Items;

            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz usunąć pozycję {((Book)dataGrid.CurrentItem).BookTitle}?",
                "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                if (items.CanRemove)
                {
                    SQLiteConnection conn = Connection();
                    SQLiteCommand cmd = conn.CreateCommand();

                    cmd.CommandText = "DELETE FROM Books WHERE BookID = " + ((Book)dataGrid.CurrentItem).BookID;
                    cmd.ExecuteNonQuery();

                    _viewModel.LoadDataCommand.Execute(null);

                    conn.Close();

                    MessageBox.Show("Usunięto wybraną pozycję", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    System.Windows.MessageBox.Show("Nie można usunąć określonej pozycji", "Błąd",
                        System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
                }
            }

        }


        private void btnZatwierdz(object sender, RoutedEventArgs e)
        {
      
            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz zmodyfikować wybrane pozycję?",
                "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                SQLiteConnection conn = Connection();
                for (int i = 0; i < list.Count; i++)
                {
                    string status = "";
                    Book bk = (Book)list[i].Item;

                    
                    SQLiteCommand cmd = conn.CreateCommand();


                    if (bk.Status == "Dostępna")
                    {
                        status = "Available";
                    }
                    else if (bk.Status == "Wypożyczona")
                    {
                        status = "Borrowed";
                    }
                    else if (bk.Status == "Zarezerwowana")
                    {
                        status = "Reserved";
                    }

                    cmd.CommandText = "UPDATE Books SET BookTitle = '" +
                        bk.BookTitle + "', BookAuthor = '" + bk.BookAuthor + "', Genre = '" + bk.Genre + "', ISBN ='"
                        + bk.ISBN + "', Status = '" + status + "' WHERE BookID = " + bk.BookID;

                    cmd.ExecuteNonQuery();
                }

                _viewModel.LoadDataCommand.Execute(null);

                MessageBox.Show("Zaktualizowano wybrane pozycję", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);

            }
            Zatwierdz.Visibility = Visibility.Collapsed;
            Anuluj.Visibility = Visibility.Collapsed;
            Dodawanie.Visibility = Visibility.Visible;
            dataGrid.IsReadOnly = true;
        }

        private void btnAnuluj(object sender, RoutedEventArgs e)
        {
            Zatwierdz.Visibility = Visibility.Collapsed;
            Anuluj.Visibility = Visibility.Collapsed;
            Dodawanie.Visibility = Visibility.Visible;
        }

        private void btnDodaj(object sender, RoutedEventArgs e)
        {
            addingBook adding = new addingBook();
            adding.Show();

            if (PresentationSource.FromVisual(adding) == null)
            {
                _viewModel.LoadDataCommand.Execute(null);
                
            }
            
        }

        private void Modyfikuj(object sender, RoutedEventArgs e)
        {
            dataGrid.IsReadOnly = false;

            Dodawanie.Visibility = Visibility.Collapsed;
            Zatwierdz.Visibility = Visibility.Visible;
            Anuluj.Visibility = Visibility.Visible;

        }

        private void dataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            var rowIndex = dataGrid.SelectedIndex;

            var row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(rowIndex);

            if (!list.Contains(row))
            {
                list.Add(row);
            }

        }

    }
}