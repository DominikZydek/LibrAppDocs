﻿using Librapp.MVVM.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Path = System.IO.Path;

namespace Librapp.MVVM.View
{
    /// <summary>
    /// Logika interakcji dla klasy AdminView3.xaml
    /// </summary>
    public partial class AdminView3 : UserControl
    {
        private AdminView3Model _viewModel;
        private List<DataGridRow> list = new List<DataGridRow>();

        public AdminView3()
        {
            InitializeComponent();
            _viewModel = new AdminView3Model();
            DataContext = _viewModel;
            _viewModel.LoadDataCommand.Execute(null);
        }

        private SQLiteConnection Connection() //Łączenie z bazą danych
        {
            //Określenie ścieżki bazy danych
            var connection = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(connection).Parent.FullName;
            string dbpath = Path.Combine(projectDirectory + "\\DatabaseFiles\\LibraryDatabase.db");

            //Łączenie z bazą danych
            var sqlite_conn = new SQLiteConnection("Data Source =" + dbpath);

            //Sprawdzenie połączenia z bazą
            sqlite_conn.Open();


            return sqlite_conn;
        }

        private void Usun(object sender, RoutedEventArgs e)
        {
            IEditableCollectionView items = dataGrid.Items;

            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz usunąć wypożyczenie {((newBorrowing)dataGrid.CurrentItem).BookTitle}?",
                "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                if (items.CanRemove)
                {
                    SQLiteConnection conn = Connection();
                    SQLiteCommand cmd = conn.CreateCommand();

                    cmd.CommandText = "DELETE FROM Borrowings WHERE BorrowingID = " + ((newBorrowing)dataGrid.CurrentItem).BorrowingID;
                    cmd.ExecuteNonQuery();

                    _viewModel.LoadDataCommand.Execute(null);

                    conn.Close();

                    MessageBox.Show("Usunięto wybrane wypożyczenie", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    System.Windows.MessageBox.Show("Nie można usunąć wybranego wypożyczenia", "Błąd",
                        System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
                }
            }

        }


        private void btnZatwierdz(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz zmodyfikować wybrane wypożyczenia?",
                "Potwierdzenie", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                SQLiteConnection conn = Connection();              
                for (int i = 0; i < list.Count; i++)
                {
                    newBorrowing borrowing = (newBorrowing)list[i].Item;
                    SQLiteCommand cmd = conn.CreateCommand();

                    cmd.CommandText = $"UPDATE Borrowings SET "
                    + $"BorrowingDate = '{dateConvert(borrowing.BorrowingDate)}'" +
                    $", DueDate = '{dateConvert(borrowing.DueDate)}' WHERE BorrowingID = {borrowing.BorrowingID}";

                    cmd.ExecuteNonQuery();
                }
                _viewModel.LoadDataCommand.Execute(null);

                MessageBox.Show("Zaktualizowano wypożyczenie", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);

            }
            Zatwierdz.Visibility = Visibility.Collapsed;
            Anuluj.Visibility = Visibility.Collapsed;
            dataGrid.IsReadOnly = true;
        }

        private void btnAnuluj(object sender, RoutedEventArgs e)
        {
            Zatwierdz.Visibility = Visibility.Collapsed;
            Anuluj.Visibility = Visibility.Collapsed;
        }


        private void Modyfikuj(object sender, RoutedEventArgs e)
        {
            dataGrid.IsReadOnly = false;
            Zatwierdz.Visibility = Visibility.Visible;
            Anuluj.Visibility = Visibility.Visible;

        }

        
        private string dateConvert(DateTime dt)
        {
            string str = dt.ToString("yyyy/MM/dd");
            if (str.Contains('.'))
            {
                return str.Replace('.', '-');
            }
            else if(str.Contains('/'))
            {
                return str.Replace('/', '-');
            }
            else if (str.Contains(','))
            {
                return str.Replace(',', '-');
            }
            return str;
        }

        private void dataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            var rowIndex = dataGrid.SelectedIndex;

            var row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(rowIndex);

            if (!list.Contains(row))
            {
                list.Add(row);
            }
        }
    }
}
