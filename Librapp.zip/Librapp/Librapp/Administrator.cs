﻿using System;
using System.Collections.Generic;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Librapp
{
    public class Administrator
    {
        public int AdminID { get; set; }
        public string JobTitle { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Login { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public Administrator(int adminID, string jobTitle, string name, string surname, string login, string email, string password) // konstruktor
        {
            AdminID = adminID;
            JobTitle = jobTitle;
            Name = name;
            Surname = surname;
            Login = login;
            Email = email;
            Password = password;
        }
        public Administrator() { } // konstruktor domyślny

        public Administrator(Administrator administratorToCopy) // konstruktor kopiujący
        {
            this.AdminID = administratorToCopy.AdminID;
            this.JobTitle = administratorToCopy.JobTitle;
            this.Name = administratorToCopy.Name;
            this.Surname = administratorToCopy.Surname;
            this.Login = administratorToCopy.Login;
            this.Email = administratorToCopy.Email;
            this.Password = administratorToCopy.Password;
        }
    }
}
