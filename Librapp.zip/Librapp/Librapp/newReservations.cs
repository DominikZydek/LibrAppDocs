﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Librapp
{
    public class newReservations
    {
        public int ReservationID { get; set; }
        public string Login { get; set; }
        public string BookTitle { get; set; }
        public string BookAuthor { get; set; }
        public DateTime ReservationDate { get; set; }
        public DateTime ExpirationDate { get; set; }

        public newReservations(int reservationID, string login, string bookTitle, string bookAuthor,
            DateTime reservationDate, DateTime expirationDate)
        {
            ReservationID = reservationID;
            Login = login;
            BookTitle = bookTitle;
            BookAuthor = bookAuthor;
            ReservationDate = reservationDate;
            ExpirationDate = expirationDate;
        }


    }
}
